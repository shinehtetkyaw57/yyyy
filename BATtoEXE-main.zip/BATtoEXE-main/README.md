# BATtoEXE
A simple BAT to EXE program that lets you.. well, Convert a BAT/Batch file to an EXE/Executable file.
Created by ItzJackOn,
Please do not modify or distribute my content without my permission.

HOW TO USE (.exe file):
Download the EXE file and open it
Drag and drop a file into the program and it will convert!

HOW TO USE (open-source/BAT file code):

Download the BAT file (the bat file is the exe file before I converted it to exe using the converter, lol)
Right click on it and press edit in notepad or in visual studio (any text editor can do)
and take a look at the code
Look at the first 4 lines of this README before modifying or distributing it, Though.

Thanks for reading

-Jack
